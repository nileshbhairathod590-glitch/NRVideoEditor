# NR Video Editor — v1

Android Studio project for the first NR video editor prototype.

### Included
- Video picker
- Video preview/playback
- Start/end trim points
- MP4 export to `Movies/NR Video Editor`
- Initial text-overlay UI

### Next development stages
1. Real text overlay rendering
2. Music/audio import
3. Split + merge timeline
4. Filters/effects
5. Speed control
6. Crop/rotate
7. Stickers/transitions
8. 1080p export controls
9. Project/draft saving

### Build
Open this folder in Android Studio, allow Gradle to sync, then Run on an Android 7.0+ device/emulator.
