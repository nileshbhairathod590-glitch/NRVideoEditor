package com.nr.videoeditor

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NRApp() }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun NRApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Select a video to start") }
    var overlayText by remember { mutableStateOf("") }
    var showTextBox by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            startMs = 0L
            endMs = 0L
            status = "Video loaded"
        }
    }

    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(it))
                prepare()
                playWhenReady = false
            }
        }
    }

    DisposableEffect(player) {
        onDispose { player?.release() }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("NR Video Editor") },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF171717),
                        titleContentColor = Color.White
                    )
                )
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().background(Color(0xFF0D0D0D))
                    .padding(padding).padding(12.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().weight(1f).background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (player != null) {
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    this.player = player
                                    useController = true
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text("🎬\n\nChoose a video", color = Color.Gray)
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text(status, color = Color.LightGray)
                Spacer(Modifier.height(8.dp))

                if (showTextBox) {
                    OutlinedTextField(
                        value = overlayText,
                        onValueChange = { overlayText = it },
                        label = { Text("Text overlay (UI preview)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { picker.launch("video/*") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.VideoLibrary, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Video")
                    }
                    OutlinedButton(
                        onClick = { showTextBox = !showTextBox },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.TextFields, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Text")
                    }
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            player?.seekTo(0)
                            startMs = 0L
                            status = "Start point set: 0s"
                        },
                        enabled = player != null,
                        modifier = Modifier.weight(1f)
                    ) { Text("Set Start") }

                    OutlinedButton(
                        onClick = {
                            player?.let {
                                endMs = it.currentPosition
                                status = "End point set: ${endMs / 1000}s"
                            }
                        },
                        enabled = player != null,
                        modifier = Modifier.weight(1f)
                    ) { Text("Set End") }
                }

                Spacer(Modifier.height(8.dp))

                Button(
                    onClick = {
                        val uri = videoUri
                        if (uri == null) {
                            status = "Please choose a video first"
                        } else {
                            status = "Export started..."
                            exportTrimmedVideo(context, uri, startMs, endMs) {
                                status = it
                            }
                        }
                    },
                    enabled = videoUri != null,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.FileDownload, null)
                    Spacer(Modifier.width(6.dp))
                    Text("EXPORT VIDEO")
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
private fun exportTrimmedVideo(
    context: Context,
    inputUri: Uri,
    startMs: Long,
    endMs: Long,
    onStatus: (String) -> Unit
) {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "NR_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/NR Video Editor")
    }

    val resolver = context.contentResolver
    val outputUri = resolver.insert(
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
    ) ?: run {
        onStatus("Could not create output file")
        return
    }

    val temp = File(context.cacheDir, "nr_export_${System.currentTimeMillis()}.mp4")

    val clipping = MediaItem.ClippingConfiguration.Builder()
        .setStartPositionMs(startMs)
        .apply { if (endMs > startMs) setEndPositionMs(endMs) }
        .build()

    val mediaItem = MediaItem.Builder()
        .setUri(inputUri)
        .setClippingConfiguration(clipping)
        .build()

    val edited = EditedMediaItem.Builder(mediaItem).build()

    val transformer = Transformer.Builder(context)
        .setVideoMimeType("video/avc")
        .setAudioMimeType("audio/mp4a-latm")
        .addListener(object : Transformer.Listener {
            override fun onCompleted(
                composition: androidx.media3.transformer.Composition,
                result: Transformer.ExportResult
            ) {
                try {
                    resolver.openOutputStream(outputUri)?.use { out ->
                        temp.inputStream().use { input -> input.copyTo(out) }
                    }
                    temp.delete()
                    onStatus("Export complete! Saved to Movies/NR Video Editor")
                } catch (e: Exception) {
                    resolver.delete(outputUri, null, null)
                    onStatus("Export failed: ${e.message}")
                }
            }

            override fun onError(
                composition: androidx.media3.transformer.Composition,
                result: Transformer.ExportResult,
                exception: ExportException
            ) {
                resolver.delete(outputUri, null, null)
                temp.delete()
                onStatus("Export failed: ${exception.message}")
            }
        })
        .build()

    transformer.start(edited, temp.absolutePath)
}
